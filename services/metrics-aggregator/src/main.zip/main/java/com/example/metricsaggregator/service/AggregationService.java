package com.example.metricsaggregator.service;

import com.example.common.MetricRaw;
import com.example.metricsaggregator.domain.window.MinuteAggregate;
import com.example.metricsaggregator.domain.window.WindowState;
import com.example.metricsaggregator.kafka.AggregatesProducer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AggregationService {
  private final WindowState state = new WindowState();
  private final MetricMinuteService metricMinuteService;
  private final AggregatesProducer producer;

  public void accept(MetricRaw m){
    state.add(m.service(), m.ts(), m.rps(), m.p95ms(), m.cpu(), m.queueDepth());
  }

  @Transactional
  public void flushClosedWindows(){
    List<MinuteAggregate> closed = state.extractClosed();
    if (closed.isEmpty()) return;

    // Сохраняем пачкой (JPA), затем шлём в Kafka
    metricMinuteService.saveOrUpdateAll(closed);
    for (MinuteAggregate a : closed) {
      try {
        producer.send(a);
      } catch (Exception e) {
        log.error("Kafka send failed: service={}, ts={}, err={}",
                a.service(), a.ts(), e.toString(), e);
      }
    }
  }
}
